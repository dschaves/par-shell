#ifndef PAR_RUN_H
#define PAR_RUN_H

void par_run(char *argVector[]);

#endif
