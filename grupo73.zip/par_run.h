#ifndef PAR_RUN_H
#define PAR_RUN_H

int par_run(char **argVector);

#endif
