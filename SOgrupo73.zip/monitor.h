#ifndef MONITOR_H
#define MONITOR_H

void* monitor(void* argstruct);

#endif
